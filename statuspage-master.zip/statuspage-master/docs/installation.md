# Installation

## Using pip
The prefered way to install statuspage is with Pythons package manager pip:

    pip install statuspage
    
## Binaries
### macOS (64Bit)
    curl -L https://github.com/jayfk/statuspage/releases/download/0.6.0/statuspage-darwin-64 > /usr/local/bin/statuspage
    chmod +x /usr/local/bin/statuspage
    
### Linux (64Bit)
    curl -L https://github.com/jayfk/statuspage/releases/download/0.6.0/statuspage-linux-64 > /usr/local/bin/statuspage
    chmod +x /usr/local/bin/statuspage